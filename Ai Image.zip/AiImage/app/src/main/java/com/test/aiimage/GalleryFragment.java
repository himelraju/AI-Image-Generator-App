package com.test.aiimage;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.appbar.MaterialToolbar;
import android.view.Menu;
import android.content.Intent;
import androidx.appcompat.widget.PopupMenu;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.os.Build;

public class GalleryFragment extends Fragment implements GalleryAdapter.OnItemClickListener {
    private static final int PERMISSION_REQUEST_CODE = 123;
    private static final int REQUEST_DELETE_CODE = 124;
    private RecyclerView recyclerView;
    private GalleryAdapter adapter;
    private Set<GalleryItem> selectedItems = new HashSet<>();
    private boolean isSelectionMode = false;
    private String currentSortOrder = MediaStore.Images.Media.DATE_ADDED + " DESC";
    private String currentStyle = "all";
    private MaterialToolbar toolbar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_gallery, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        toolbar = view.findViewById(R.id.toolbar);
        adapter = new GalleryAdapter(this);
        recyclerView.setAdapter(adapter);
        loadImages();
        setupFilterChips(view);
        setupSortButton(view);
        setupFab(view);
        setupToolbar();
    }

    private void setupFilterChips(View view) {
        ChipGroup styleChips = view.findViewById(R.id.styleChips);
        styleChips.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.filter_chip_all) {
                currentStyle = "all";
            } else if (checkedId == R.id.filter_chip_photographic) {
                currentStyle = "photographic";
            }
            loadImages();
        });
    }

    private void setupSortButton(View view) {
        view.findViewById(R.id.sortButton).setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(requireContext(), v);
            popup.getMenu().add("Newest First");
            popup.getMenu().add("Oldest First");
            popup.getMenu().add("Size");
            popup.setOnMenuItemClickListener(item -> {
                switch (item.getTitle().toString()) {
                    case "Newest First":
                        currentSortOrder = MediaStore.Images.Media.DATE_ADDED + " DESC";
                        break;
                    case "Oldest First":
                        currentSortOrder = MediaStore.Images.Media.DATE_ADDED + " ASC";
                        break;
                    case "Size":
                        currentSortOrder = MediaStore.Images.Media.SIZE + " DESC";
                        break;
                }
                loadImages();
                return true;
            });
            popup.show();
        });
    }

    private void setupFab(View view) {
        view.findViewById(R.id.shareFab).setOnClickListener(v -> {
            if (selectedItems.isEmpty()) return;
            shareImages(selectedItems);
        });
    }

    private void setupToolbar() {
        toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_select) {
                toggleSelectionMode();
                return true;
            } else if (item.getItemId() == R.id.action_delete) {
                deleteSelectedItems();
                return true;
            }
            return false;
        });
    }

    private void toggleSelectionMode() {
        isSelectionMode = !isSelectionMode;
        adapter.setSelectionMode(isSelectionMode);
        updateToolbarState();
    }

    private void updateToolbarState() {
        Menu menu = toolbar.getMenu();
        menu.findItem(R.id.action_delete).setVisible(isSelectionMode);
        menu.findItem(R.id.action_select).setIcon(
            isSelectionMode ? R.drawable.ic_close : R.drawable.ic_select
        );
        toolbar.setTitle(isSelectionMode ? R.string.select_items : R.string.gallery);
    }

    @Override
    public void onItemClick(GalleryItem item) {
        if (isSelectionMode) {
            adapter.toggleSelection(item);
        } else {
            showImageDetails(item);
        }
    }

    @Override
    public void onItemLongClick(GalleryItem item) {
        if (!isSelectionMode) {
            toggleSelectionMode();
            adapter.toggleSelection(item);
        }
    }

    @Override
    public void onSelectionChanged(int count) {
        toolbar.setTitle((CharSequence)(count + " selected"));
        toolbar.getMenu().findItem(R.id.action_delete)
            .setVisible(count > 0);
    }

    private void deleteSelectedItems() {
        Set<GalleryItem> itemsToDelete = adapter.getSelectedItems();
        if (itemsToDelete.isEmpty()) return;

        if (checkPermissions()) {
            new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.delete_selected)
                .setMessage(getString(R.string.delete_confirm))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    deleteImages(itemsToDelete);
                    adapter.clearSelection();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        }
    }

    private boolean checkPermissions() {
        if (ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }

    private void deleteImages(Set<GalleryItem> items) {
        int deletedCount = 0;
        ContentResolver resolver = requireContext().getContentResolver();

        for (GalleryItem item : items) {
            Uri deleteUri = ContentUris.withAppendedId(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, item.id);
            try {
                deletedCount += resolver.delete(deleteUri, null, null);
            } catch (SecurityException e) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    try {
                        IntentSender intentSender = MediaStore.createDeleteRequest(
                            resolver, Arrays.asList(deleteUri)).getIntentSender();
                        startIntentSenderForResult(intentSender, REQUEST_DELETE_CODE,
                            null, 0, 0, 0, null);
                        return;
                    } catch (SendIntentException sendIntentException) {
                        // Handle error
                    }
                }
            }
        }

        if (deletedCount > 0) {
            Toast.makeText(requireContext(), 
                String.format("Deleted %d images", deletedCount), 
                Toast.LENGTH_SHORT).show();
            loadImages();
        }
        toggleSelectionMode();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                deleteSelectedItems();
            } else {
                Toast.makeText(requireContext(), 
                    "Storage permission required to delete images", 
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_DELETE_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                loadImages();
                toggleSelectionMode();
            }
        }
    }

    private void showImageDetails(GalleryItem item) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.bottom_sheet_image_details, null);
        // Setup dialog content
        dialog.setContentView(dialogView);
        dialog.show();
    }

    private void shareImages(Set<GalleryItem> items) {
        if (items.isEmpty()) return;

        ArrayList<Uri> imageUris = new ArrayList<>();
        for (GalleryItem item : items) {
            Uri shareUri = ContentUris.withAppendedId(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, item.id);
            imageUris.add(shareUri);
        }

        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
        shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris);
        shareIntent.setType("image/*");
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        
        try {
            startActivity(Intent.createChooser(shareIntent, getString(R.string.share)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(requireContext(), "No app available to share", 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void loadImages() {
        String[] projection = {
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED
        };

        String selection = MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?";
        String[] selectionArgs = {"AI_IMG_%"};
        if (!currentStyle.equals("all")) {
            selection += " AND " + MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?";
            selectionArgs = new String[]{"AI_IMG_%", "%" + currentStyle + "%"};
        }
        String sortOrder = currentSortOrder;

        try (Cursor cursor = requireContext().getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                sortOrder)) {

            List<GalleryItem> items = new ArrayList<>();
            while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                long dateAdded = cursor.getLong(2);
                
                items.add(new GalleryItem(
                    id,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI + "/" + id,
                    name,
                    dateAdded
                ));
            }
            adapter.submitList(items);
        }
    }
}
