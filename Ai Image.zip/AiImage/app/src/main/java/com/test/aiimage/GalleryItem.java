package com.test.aiimage;

import java.util.Objects;

public class GalleryItem {
    public final long id;
    public final String uri;
    public final String name;
    public final long dateAdded;

    public GalleryItem(long id, String uri, String name, long dateAdded) {
        this.id = id;
        this.uri = uri;
        this.name = name;
        this.dateAdded = dateAdded;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GalleryItem that = (GalleryItem) o;
        return id == that.id &&
               dateAdded == that.dateAdded &&
               Objects.equals(uri, that.uri) &&
               Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, uri, name, dateAdded);
    }
}
