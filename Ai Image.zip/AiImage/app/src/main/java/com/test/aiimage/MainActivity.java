package com.test.aiimage;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    public static final String DEFAULT_API_KEY = "sk-DXPQsq2xnPEsoXhQH0za5mHCkoseB2qOd7u9mv34NuDrHXpy";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeDefaultApiKey();

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        NavController navController = navHostFragment.getNavController();
        
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        NavigationUI.setupWithNavController(bottomNav, navController);
    }

    private void initializeDefaultApiKey() {
        AppSettings settings = new AppSettings(this);
        if (settings.getApiKey().isEmpty()) {
            settings.setDefaultApiKey(DEFAULT_API_KEY);
        }
    }
}