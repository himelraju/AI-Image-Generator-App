package com.test.aiimage;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.slider.Slider;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.button.MaterialButton;
import android.widget.ImageView;

import java.io.ByteArrayInputStream;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import java.io.OutputStream;
import java.util.Date;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.divider.MaterialDivider;

public class GenerateFragment extends Fragment {
    // Remove the API_KEY constant as it's now handled by AppSettings
    private TextInputEditText promptInput;
    private Slider cfgScaleSlider;
    private ChipGroup sizeChipGroup;
    private ImageView resultImage;
    private View progressIndicator;
    private MaterialButton generateButton;
    private StableDiffusionApi api;
    private AppSettings appSettings;
    private MaterialSwitch advancedSwitch;
    private View advancedOptions;
    private TextInputEditText seedInput;
    private MaterialSwitch upscaleSwitch;
    private Slider stepsSlider;
    private ChipGroup stylePresetChipGroup;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_generate, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        appSettings = new AppSettings(requireContext());
        setupViews(view);
        setupApi();
        setupListeners();
        loadDefaultSettings();
        setupAdvancedOptions(view);
    }

    private void setupViews(View view) {
        promptInput = view.findViewById(R.id.promptInput);
        cfgScaleSlider = view.findViewById(R.id.cfgScaleSlider);
        sizeChipGroup = view.findViewById(R.id.sizeChipGroup);
        resultImage = view.findViewById(R.id.resultImage);
        progressIndicator = view.findViewById(R.id.progressIndicator);
        generateButton = view.findViewById(R.id.generateButton);
        stepsSlider = view.findViewById(R.id.stepsSlider);
        stylePresetChipGroup = view.findViewById(R.id.stylePresetChipGroup);
        advancedSwitch = view.findViewById(R.id.advancedSwitch);
        advancedOptions = view.findViewById(R.id.advancedOptions);
        seedInput = view.findViewById(R.id.seedInput);
        upscaleSwitch = view.findViewById(R.id.upscaleSwitch);
    }

    private void setupApi() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
            .addInterceptor(logging)
            .build();

        Retrofit retrofit = new Retrofit.Builder()
            .baseUrl("https://api.stability.ai/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build();

        api = retrofit.create(StableDiffusionApi.class);
    }

    private void setupListeners() {
        generateButton.setOnClickListener(v -> generateImage());
        cfgScaleSlider.addOnChangeListener((slider, value, fromUser) -> {
            // Handle CFG scale changes
        });

        sizeChipGroup.setOnCheckedChangeListener((group, checkedId) -> {
            // Handle size selection changes
        });
    }

    private void setupAdvancedOptions(View view) {
        advancedSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            advancedOptions.setVisibility(isChecked ? View.VISIBLE : View.GONE);
        });

        stylePresetChipGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String stylePreset = "";
            if (checkedId == R.id.stylePhotographic) {
                stylePreset = "photographic";
            } else if (checkedId == R.id.styleDigitalArt) {
                stylePreset = "digital-art";
            } else if (checkedId == R.id.styleAnime) {
                stylePreset = "anime";
            }
            // Update the request style preset when generating
        });

        stepsSlider.addOnChangeListener((slider, value, fromUser) -> {
            // Update steps in real time
        });
    }

    private void loadDefaultSettings() {
        int defaultSize = appSettings.getDefaultImageSize();
        if (defaultSize == 512) {
            sizeChipGroup.check(R.id.size512);
        } else {
            sizeChipGroup.check(R.id.size1024);
        }
        cfgScaleSlider.setValue(appSettings.getDefaultCfgScale());
        stepsSlider.setValue(appSettings.getDefaultSteps());
        seedInput.setText(String.valueOf(appSettings.getDefaultSeed()));
        upscaleSwitch.setChecked(appSettings.shouldAutoUpscale());
    }

    private void generateImage() {
        String prompt = promptInput.getText().toString();
        if (prompt.isEmpty()) {
            promptInput.setError("Please enter a prompt");
            return;
        }

        int size = sizeChipGroup.getCheckedChipId() == R.id.size512 ? 512 : 1024;
        int cfgScale = (int) cfgScaleSlider.getValue();

        progressIndicator.setVisibility(View.VISIBLE);
        generateButton.setEnabled(false);
        resultImage.setImageDrawable(null);

        ImageRequest request = new ImageRequest(prompt);
        request.setSize(size);
        request.setCfgScale(cfgScale);
        request.setSteps((int) stepsSlider.getValue());
        
        if (!seedInput.getText().toString().isEmpty()) {
            request.setSeed(Long.parseLong(seedInput.getText().toString()));
        }
        
        if (upscaleSwitch.isChecked()) {
            request.setUpscale(true);
        }

        // Set style preset based on chip selection
        int checkedId = stylePresetChipGroup.getCheckedChipId();
        if (checkedId != View.NO_ID) {
            String stylePreset = "photographic"; // default
            if (checkedId == R.id.styleDigitalArt) {
                stylePreset = "digital-art";
            } else if (checkedId == R.id.styleAnime) {
                stylePreset = "anime";
            }
            request.setStylePreset(stylePreset);
        }

        api.generateImage(
            appSettings.getDefaultModel(),  // Add engine ID parameter
            "Bearer " + appSettings.getApiKey(),
            "application/json",
            "application/json",
            request
        ).enqueue(new Callback<ImageResponse>() {
            @Override
            public void onResponse(Call<ImageResponse> call, Response<ImageResponse> response) {
                if (!isAdded()) return;
                progressIndicator.setVisibility(View.GONE);
                generateButton.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    String base64Image = response.body().getImageBase64();
                    if (base64Image != null) {
                        byte[] imageBytes = Base64.decode(base64Image, Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeStream(
                            new ByteArrayInputStream(imageBytes));
                        resultImage.setImageBitmap(bitmap);
                        saveImageToGallery(bitmap);
                    } else {
                        showError("No image generated");
                    }
                } else {
                    showError("Error: " + response.code() + " " + response.message());
                }
            }

            @Override
            public void onFailure(Call<ImageResponse> call, Throwable t) {
                if (!isAdded()) return;
                progressIndicator.setVisibility(View.GONE);
                generateButton.setEnabled(true);
                showError("Network error: " + t.getMessage());
            }
        });
    }

    private void saveImageToGallery(Bitmap bitmap) {
        if (!appSettings.shouldSaveImages()) return;

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, "AI_IMG_" + new Date().getTime());
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

        try {
            Uri uri = requireContext().getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            OutputStream out = requireContext().getContentResolver().openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.close();
        } catch (Exception e) {
            showError("Failed to save image");
        }
    }

    private void showError(String message) {
        if (getContext() != null) {
            Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
        }
    }
}
