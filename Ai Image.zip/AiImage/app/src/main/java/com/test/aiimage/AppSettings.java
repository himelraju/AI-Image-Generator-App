package com.test.aiimage;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.preference.PreferenceManager;

public class AppSettings {
    private final SharedPreferences prefs;

    public AppSettings(Context context) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public void setDefaultApiKey(String apiKey) {
        prefs.edit().putString("api_key", apiKey).apply();
    }

    public String getApiKey() {
        String customKey = prefs.getString("api_key", "");
        return customKey.isEmpty() ? MainActivity.DEFAULT_API_KEY : customKey;
    }

    public int getDefaultImageSize() {
        return Integer.parseInt(prefs.getString("default_size", "1024"));
    }

    public int getDefaultCfgScale() {
        return prefs.getInt("default_cfg_scale", 7);
    }

    public int getDefaultSteps() {
        return prefs.getInt("default_steps", 30);
    }

    public boolean shouldSaveImages() {
        return prefs.getBoolean("save_images", true);
    }

    public String getDefaultModel() {
        return prefs.getString("default_model", "stable-diffusion-v1-6");
    }

    public float getNoiseLevel() {
        return prefs.getInt("noise_level", 20) / 100f;
    }

    public boolean shouldAutoUpscale() {
        return prefs.getBoolean("auto_upscale", false);
    }

    public long getDefaultSeed() {
        String seed = prefs.getString("default_seed", "");
        return seed.isEmpty() ? System.currentTimeMillis() : Long.parseLong(seed);
    }

    public int getBatchSize() {
        return prefs.getInt("batch_size", 1);
    }

    public boolean shouldGenerateVariations() {
        return prefs.getBoolean("batch_variations", false);
    }
}
