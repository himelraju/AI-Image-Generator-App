package com.test.aiimage;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.card.MaterialCardView;
import java.util.HashSet;
import java.util.Set;

public class GalleryAdapter extends ListAdapter<GalleryItem, GalleryAdapter.ViewHolder> {
    private final OnItemClickListener listener;
    private Set<GalleryItem> selectedItems = new HashSet<>();
    private boolean selectionMode = false;
    
    public interface OnItemClickListener {
        void onItemClick(GalleryItem item);
        void onItemLongClick(GalleryItem item);
        void onSelectionChanged(int count);
    }
    
    public GalleryAdapter(OnItemClickListener listener) {
        super(new DiffUtil.ItemCallback<GalleryItem>() {
            @Override
            public boolean areItemsTheSame(GalleryItem oldItem, GalleryItem newItem) {
                return oldItem.id == newItem.id;
            }

            @Override
            public boolean areContentsTheSame(GalleryItem oldItem, GalleryItem newItem) {
                return oldItem.equals(newItem);
            }
        });
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_gallery, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        GalleryItem item = getItem(position);
        holder.bind(item, selectedItems.contains(item), selectionMode, listener);
    }

    public Set<GalleryItem> getSelectedItems() {
        return new HashSet<>(selectedItems);
    }

    public void clearSelection() {
        selectedItems.clear();
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final MaterialCardView cardView;
        private final ImageView imageView;
        private final TextView dateText;
        private final CheckBox checkBox;

        ViewHolder(View view) {
            super(view);
            cardView = (MaterialCardView) view;
            imageView = view.findViewById(R.id.imageView);
            dateText = view.findViewById(R.id.dateText);
            checkBox = view.findViewById(R.id.checkBox);
        }

        void bind(GalleryItem item, boolean selected, boolean selectionMode, OnItemClickListener listener) {
            // Image loading with error handling
            Glide.with(imageView)
                .load(Uri.parse(item.uri))
                .placeholder(R.drawable.image_placeholder)
                .error(R.drawable.image_error)
                .transition(DrawableTransitionOptions.withCrossFade())
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model,
                            Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model,
                                                   Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                })
                .into(imageView);
            
            // Date text
            dateText.setText(DateUtils.getRelativeTimeSpanString(
                item.dateAdded * 1000,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS
            ));
            
            // Selection state
            cardView.setChecked(selected);
            checkBox.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
            checkBox.setChecked(selected);
            
            // Click listeners
            View.OnClickListener clickListener = v -> {
                if (listener != null) {
                    if (selectionMode) {
                        checkBox.toggle();
                    }
                    listener.onItemClick(item);
                }
            };
            
            cardView.setOnClickListener(clickListener);
            checkBox.setOnClickListener(clickListener);
            
            cardView.setOnLongClickListener(v -> {
                if (listener != null) {
                    listener.onItemLongClick(item);
                    return true;
                }
                return false;
            });
        }
    }

    public void toggleSelection(GalleryItem item) {
        if (selectedItems.contains(item)) {
            selectedItems.remove(item);
        } else {
            selectedItems.add(item);
        }
        notifyDataSetChanged();
        listener.onSelectionChanged(selectedItems.size());
    }

    public void setSelectionMode(boolean enabled) {
        selectionMode = enabled;
        if (!enabled) {
            selectedItems.clear();
        }
        notifyDataSetChanged();
    }
}
