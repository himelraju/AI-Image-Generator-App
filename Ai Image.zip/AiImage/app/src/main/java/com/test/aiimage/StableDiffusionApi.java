package com.test.aiimage;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public interface StableDiffusionApi {
    @POST("v1/generation/{engine_id}/text-to-image")
    Call<ImageResponse> generateImage(
        @Path("engine_id") String engineId,
        @Header("Authorization") String authorization,
        @Header("Content-Type") String contentType,
        @Header("Accept") String accept,
        @Body ImageRequest request
    );
}

class ImageRequest {
    @SerializedName("text_prompts")
    private List<TextPrompt> textPrompts;
    @SerializedName("cfg_scale")
    private int cfgScale;
    @SerializedName("height")
    private int height;
    @SerializedName("width")
    private int width;
    @SerializedName("samples")
    private int samples;
    @SerializedName("steps")
    private int steps;
    @SerializedName("style_preset")
    private String stylePreset;
    @SerializedName("noise_level")
    private float noiseLevel;
    @SerializedName("upscale")
    private boolean upscale;
    @SerializedName("seed")
    private long seed;
    @SerializedName("init_image_mode")
    private String initImageMode;
    @SerializedName("image_strength")
    private float imageStrength;

    public ImageRequest(String prompt) {
        this.textPrompts = List.of(new TextPrompt(prompt, 1));
        this.cfgScale = 7;
        this.height = 1024;
        this.width = 1024;
        this.samples = 1;
        this.steps = 30;
        this.stylePreset = "photographic";
    }

    public void setSize(int size) {
        this.height = size;
        this.width = size;
    }

    public void setCfgScale(int cfgScale) {
        this.cfgScale = cfgScale;
    }

    public void setSteps(int steps) {
        this.steps = steps;
    }

    public void setSeed(long seed) {
        this.seed = seed;
    }

    public void setUpscale(boolean upscale) {
        this.upscale = upscale;
    }

    public void setStylePreset(String stylePreset) {
        this.stylePreset = stylePreset;
    }

    public void setNoiseLevel(float noiseLevel) {
        this.noiseLevel = noiseLevel;
    }

    public void setImageStrength(float imageStrength) {
        this.imageStrength = imageStrength;
    }

    public void setInitImageMode(String initImageMode) {
        this.initImageMode = initImageMode;
    }
}

class TextPrompt {
    @SerializedName("text")
    private String text;
    @SerializedName("weight")
    private int weight;

    public TextPrompt(String text, int weight) {
        this.text = text;
        this.weight = weight;
    }
}

class ImageResponse {
    @SerializedName("artifacts")
    private List<Artifact> artifacts;

    public String getImageBase64() {
        return artifacts != null && !artifacts.isEmpty() ? 
            artifacts.get(0).base64 : null;
    }

    static class Artifact {
        @SerializedName("base64")
        String base64;
    }
}
