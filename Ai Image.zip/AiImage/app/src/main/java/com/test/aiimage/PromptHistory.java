package com.test.aiimage;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PromptHistory {
    private static final String PREF_NAME = "prompt_history";
    private static final String KEY_PROMPTS = "prompts";
    private final SharedPreferences prefs;
    private final Gson gson;

    public PromptHistory(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void addPrompt(String prompt, String style) {
        List<PromptEntry> prompts = getPrompts();
        prompts.add(0, new PromptEntry(prompt, style));
        if (prompts.size() > 20) { // Keep last 20 prompts
            prompts = prompts.subList(0, 20);
        }
        savePrompts(prompts);
    }

    public List<PromptEntry> getPrompts() {
        String json = prefs.getString(KEY_PROMPTS, "[]");
        Type type = new TypeToken<ArrayList<PromptEntry>>(){}.getType();
        return gson.fromJson(json, type);
    }

    private void savePrompts(List<PromptEntry> prompts) {
        String json = gson.toJson(prompts);
        prefs.edit().putString(KEY_PROMPTS, json).apply();
    }

    public static class PromptEntry {
        public final String prompt;
        public final String style;
        public final long timestamp;

        public PromptEntry(String prompt, String style) {
            this.prompt = prompt;
            this.style = style;
            this.timestamp = System.currentTimeMillis();
        }
    }
}
